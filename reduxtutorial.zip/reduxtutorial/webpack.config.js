var path=require('path');
var HtmlWebPackPlugin= require('html-webpack-plugin');

module.exports={
    entry:'./src/index.js',
    output:{
        filename:'app.bundle.js',
        path:path.resolve(__dirname,'public'),
        publicPath:'/'
    },
    devServer:{
        hot:true,
        open:true,
        contentBase:path.resolve(__dirname,'public'),
        historyApiFallback: true
    },
    module:{
        rules:[
            {
                test:/\.(js|jsx)$/,
                exclude:/node_modules/,
                use:['babel-loader']
            }
        ]
    },
    plugins:[
        new HtmlWebPackPlugin({
            filename:'index.html',
            template:'./indexTemplate.html'
        })
    ],

}