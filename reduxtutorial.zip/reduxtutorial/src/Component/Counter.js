import React from 'react';
import {Action1,Action2} from '../../actions';
import {connect} from 'react-redux';
class Counter extends React.Component{
	constructor(props){
		super(props);
		this.handleClick=this.handleClick.bind(this);

	}
	handleClick(actionType,event)
	{ 
		const{dispatch}=this.props;
		const value=parseInt(document.getElementById("value").textContent);
		console.log("Value After Click"+value);
		if(actionType===1) {
				this.props.Increment(value)
			}
		else{
				this.props.Decrement(value);
		}
	}
	
	render(){

		const {first}=this.props;
		return(
			<div>
			<button onClick={this.handleClick.bind(null,1)}>+ </button>
			<div id="value">{first==0 ? 0 : first.newValue}</div>
			<button onClick={this.handleClick.bind(null,2)}>-</button>
			</div>
		) 
	}
}



const mapStateToProps=(state)=>{
		console.log("Inside MapStateToProps");
	const {first}=state;
return {first};

}

const mapDispatchToProps = (dispatch) =>{
	return {
		Increment:(data) =>dispatch(Action1(data)),
		Decrement:(data) => dispatch(Action2(data))
	}
}



export default connect(mapStateToProps,mapDispatchToProps)(Counter);
