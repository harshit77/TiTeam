import React from 'react';
import Counter from './Counter';
import {connect} from 'react-redux';

class App extends React.Component {
    render() {
        const{first}=this.props;
        return (
            <div>
                {first.newValue}
          <Counter/>
                </div>
        )
    }
}



const mapStateToProps=(state)=>{
    console.log("Inside MapStateToProps");
const {first}=state;
return {first};

}


export default connect(mapStateToProps)(App);

