
import {combineReducers} from 'redux';
import first from './first';
export default ()=>combineReducers({
    first
});
